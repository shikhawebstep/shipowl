import React from 'react'

export default function ProductWise() {
  return (
    <div>ProductWise</div>
  )
}
