import React from 'react'

export default function DailySummary() {
  return (
    <div>DailySummary</div>
  )
}
