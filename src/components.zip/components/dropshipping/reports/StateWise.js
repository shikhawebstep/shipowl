import React from 'react'

export default function StateWise() {
  return (
    <div>StateWise</div>
  )
}
