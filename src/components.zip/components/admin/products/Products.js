import ProductTable from "./ProductsTable";

export default function Products() {
  return (
    <>
      <ProductTable />

    </>
  )
}
